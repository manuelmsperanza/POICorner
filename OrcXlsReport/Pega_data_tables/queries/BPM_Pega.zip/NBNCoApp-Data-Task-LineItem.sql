select TaskID, LineItem, LineItemID,
  PR_READ_FROM_STREAM('.Interval', pzInsKey, pzPVStream) "Interval", 
  PR_READ_FROM_STREAM('.TaskName', pzInsKey, pzPVStream) "TaskName"
from PR_NBNCO_DATA_TASK_LINEITEM
order by  TaskID, LineItemID