select ID,
	IssueCategory,
	IssueName,
	RootCause
from PR_NBNCO_NBNCOAPP_DATA_RCA
ORDER BY IssueCategory, IssueName