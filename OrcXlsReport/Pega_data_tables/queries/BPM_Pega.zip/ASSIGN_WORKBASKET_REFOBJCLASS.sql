select pxrefobjectclass, count(*)
FROM PC_ASSIGN_WORKBASKET
group by pxrefobjectclass