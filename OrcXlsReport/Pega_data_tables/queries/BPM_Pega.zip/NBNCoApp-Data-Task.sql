select TaskID,
  PR_READ_FROM_STREAM('.Comments', pzInsKey, pzPVStream) "Comments", 
  PR_READ_FROM_STREAM('.Effort', pzInsKey, pzPVStream) "Effort", 
  PR_READ_FROM_STREAM('.EndDate', pzInsKey, pzPVStream) "EndDate",
  PR_READ_FROM_STREAM('.GroupID', pzInsKey, pzPVStream) "GroupID",
  PR_READ_FROM_STREAM('.IsChecked', pzInsKey, pzPVStream) "IsChecked",
  PR_READ_FROM_STREAM('.SAMAttributes', pzInsKey, pzPVStream) "SAMAttributes",  
  PR_READ_FROM_STREAM('.SAMID', pzInsKey, pzPVStream) "SAMID",  
  PR_READ_FROM_STREAM('.SourceOfSAMAttributes', pzInsKey, pzPVStream) "SourceOfSAMAttributes",
  ParentProcessID,
  TaskStatus
from FW_NBNCO_NBNCOAPP_DATA_TASK
ORDER BY TaskID