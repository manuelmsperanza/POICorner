select pxrefobjectclass, count(*)
FROM PC_ASSIGN_WORKLIST
group by pxrefobjectclass