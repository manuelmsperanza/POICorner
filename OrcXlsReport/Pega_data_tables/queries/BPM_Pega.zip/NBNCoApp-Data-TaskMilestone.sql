select TaskID, milestone, type, field,
  PR_READ_FROM_STREAM('.Dependence', pzInsKey, pzPVStream) "Dependence",
  PR_READ_FROM_STREAM('.ImportExport', pzInsKey, pzPVStream) "ImportExport", 
  to_number(PR_READ_FROM_STREAM('.Sequence', pzInsKey, pzPVStream)) "Sequence", 
  to_number(PR_READ_FROM_STREAM('.Order', pzInsKey, pzPVStream)) "Order"
from PR_NBNCO_NBNCOAPP_DATA_TASKMIL
ORDER BY to_number(PR_READ_FROM_STREAM('.Order', pzInsKey, pzPVStream))