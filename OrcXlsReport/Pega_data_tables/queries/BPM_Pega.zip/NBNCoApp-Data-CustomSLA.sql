select TaskID,
  PR_READ_FROM_STREAM('.Automatic', pzInsKey, pzPVStream) "Automatic", 
  to_number(PR_READ_FROM_STREAM('.Sequence', pzInsKey, pzPVStream)) "Sequence", 
  PR_READ_FROM_STREAM('.TaskName', pzInsKey, pzPVStream) "TaskName",
  to_number(PR_READ_FROM_STREAM('.SLA', pzInsKey, pzPVStream)) "SLA",
  PR_READ_FROM_STREAM('.Dependence', pzInsKey, pzPVStream) "Dependence",
  pyLabel,
  MtoA
from PR_NBNCO_NBNCOAPP_DATA_CUSTOMS
ORDER BY TaskID