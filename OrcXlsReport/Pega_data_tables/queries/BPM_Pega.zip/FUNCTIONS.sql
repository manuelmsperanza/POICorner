SELECT PR_READ_FROM_STREAM('.pyLibraryName', pzInsKey, pzPVStream) AS "Library Name",
PR_READ_FROM_STREAM('.pyMethodName', pzInsKey, pzPVStream) AS "Method Name",
PR_READ_FROM_STREAM('.pyFunctionName', pzInsKey, pzPVStream) AS "Function Name",
PR_READ_FROM_STREAM('.pyLabel', pzInsKey, pzPVStream) AS "Label",
PR_READ_FROM_STREAM('.pyUsage', pzInsKey, pzPVStream) AS "Usage"
--PR_READ_FROM_STREAM('.pyJavaSource', pzInsKey, pzPVStream) AS "Java Source",
--A.* 
FROM PR4_RULE A
WHERE PXOBJCLASS = 'Rule-Utility-Function'
ORDER BY 1,2