SELECT PR_READ_FROM_STREAM('.pyFrom', pzInsKey, pzPVStream) AS "From",
PR_READ_FROM_STREAM('.pyToString', pzInsKey, pzPVStream) AS "To",
PR_READ_FROM_STREAM('.pySubject', pzInsKey, pzPVStream) AS "Subject",
--PR_READ_FROM_STREAM('.pzStatus', pzInsKey, pzPVStream) AS "Status",
A.* 
FROM PR_DATA A
WHERE PXOBJCLASS = 'Data-Corr-Email'
ORDER BY PXCREATEDATETIME DESC